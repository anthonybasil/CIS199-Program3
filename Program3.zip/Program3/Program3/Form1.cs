﻿// Grading ID: R3032
// Program 3
// 11-05-20
// CIS 199-01
// Program declares multiple arrays to find output values for various products (input) with
// potential discounts for quantities (input) in four states (input) with different taxes.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class Program3 : Form
    {
        public Program3()
        {
            InitializeComponent();
        }

        public const int MIN_PRODUCT_NUM = 1001; // declares min product constant
        public const int MAX_PRODUCT_NUM = 1007; // declares max product constant
        public const int MIN_QTY = 0; // declares min quantity constant

        public string[] states = { "KY", "OH",  "IN",  "IL" }; // declares states array and assigns values
        private double[] taxes = { 0.06, 0.0717, 0.07, 0.0874 }; // declares taxes array and assigns values

        public int[] products =       { 1001, 1002, 1003,  1004, 1005,  1006, 1007 }; // declares products array and assigns values
        public double[] productCost = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 }; // declares product cost array and assigns values

        public int[] qtyLowLimits = { 0,    5,    10,   20 }; // declares lower limit quantity array and assigns values
        public double[] discounts = { 0.00, 0.05, 0.10, 0.15 }; // declares discounts array and assigns values

        private void button1_Click(object sender, EventArgs e) // event handler for calculate button
        {

            bool productFound = false; // declares bool variable for whether product is found
            bool stateFound = false; // declares bool variable for whether state is found
            bool qtyFound = false; // declares bool variable for whether quantity is found

            if (selectBox.SelectedIndex >= 0) // if statement for valid combo box selection
            {
                if (int.TryParse(productInput.Text, out int productNum) && productNum >= MIN_PRODUCT_NUM && productNum <= MAX_PRODUCT_NUM) // tryparse and if statement for valid product number
                {
                    if (int.TryParse(quantityInput.Text, out int quantityNum) && quantityNum > MIN_QTY) // tryparse and if statement for valid quantity 
                    {

                        // calc product cost
                        double cost = 0; // decarles intital cost variable
                        for (int x = 0; x < products.Length && !productFound; ++x) // for statement for product input
                        {
                            if (productNum == products[x]) // if statement to assign product input to array value
                            {
                                productFound = true; // changes bool variable
                                cost = productCost[x]; // assigns cost value from array
                            }
                        }

                        // calc tax
                        double tax = 0; // declares initial tax variable
                        for (int y = 0; y < states.Length && !stateFound; ++y) // for statement for state selection
                        {
                            if (states[y] == selectBox.Text) // if statement to assignment selection to array value
                            {
                                stateFound = true; // changes bool variable 
                                tax = taxes[y]; // assigns tax value from array 
                            }
                        }

                        // calc discount
                        double discount = 0; // declares initial discount variable
                        int discountIndex = qtyLowLimits.Length - 1; // prompts discount index to start from end since using lower limites
                        while (discountIndex >= 0 && !qtyFound) // while statement to assess discount 
                        {
                            if (quantityNum >= qtyLowLimits[discountIndex]) // if statement to assess quantity input
                            { qtyFound = true; } // changes bool variable
                            else { --discountIndex; } // loops through array to find discount
                        }
                        if (qtyFound) // if statment if quantity is determined
                            discount = discounts[discountIndex]; // assigns discount from array

                        // calc final costs
                        double finalCost = cost * quantityNum; // calculates variable for final cost
                        double finalDiscCost = finalCost - discount * finalCost; // calculates variable for discounted cost
                        double finalTax = finalDiscCost * tax; // calculates variable for tax
                        double totalCost = finalDiscCost * tax + finalDiscCost; // calculates variable for total cost 

                        // input calculations
                        initialCostOut.Text = $"{finalCost:C2}"; // inputs final cost into label as formatted text
                        discCostOut.Text = $"{finalDiscCost:C2}"; // inputs discounted cost into label as formatted text
                        taxOut.Text = $"{finalTax:C2}"; // inputs tax into label as formatted text
                        totPriceOut.Text = $"{totalCost:C2}"; // inputs total cost into label as formatted text

                    }
                    else
                        MessageBox.Show("Enter valid quantity."); // displays message box for invalid quantity
                }
                else
                    MessageBox.Show("Enter valid product number."); // displays message box for invalid product number
            }
            else
                MessageBox.Show("Select valid state."); // displays message box for invalid combo box selection
        }
    }
}
