﻿namespace Program3
{
    partial class Program3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectBox = new System.Windows.Forms.ComboBox();
            this.stateLbl = new System.Windows.Forms.Label();
            this.productLbl = new System.Windows.Forms.Label();
            this.quantityLbl = new System.Windows.Forms.Label();
            this.productInput = new System.Windows.Forms.TextBox();
            this.quantityInput = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.initialCostLbl = new System.Windows.Forms.Label();
            this.discCostLbl = new System.Windows.Forms.Label();
            this.taxLbl = new System.Windows.Forms.Label();
            this.totPriceLbl = new System.Windows.Forms.Label();
            this.initialCostOut = new System.Windows.Forms.Label();
            this.discCostOut = new System.Windows.Forms.Label();
            this.taxOut = new System.Windows.Forms.Label();
            this.totPriceOut = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // selectBox
            // 
            this.selectBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectBox.FormattingEnabled = true;
            this.selectBox.Items.AddRange(new object[] {
            "KY",
            "OH",
            "IN",
            "IL"});
            this.selectBox.Location = new System.Drawing.Point(122, 29);
            this.selectBox.Name = "selectBox";
            this.selectBox.Size = new System.Drawing.Size(121, 21);
            this.selectBox.TabIndex = 0;
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(81, 32);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(35, 13);
            this.stateLbl.TabIndex = 1;
            this.stateLbl.Text = "State:";
            // 
            // productLbl
            // 
            this.productLbl.AutoSize = true;
            this.productLbl.Location = new System.Drawing.Point(69, 59);
            this.productLbl.Name = "productLbl";
            this.productLbl.Size = new System.Drawing.Size(47, 13);
            this.productLbl.TabIndex = 2;
            this.productLbl.Text = "Product:";
            // 
            // quantityLbl
            // 
            this.quantityLbl.AutoSize = true;
            this.quantityLbl.Location = new System.Drawing.Point(67, 85);
            this.quantityLbl.Name = "quantityLbl";
            this.quantityLbl.Size = new System.Drawing.Size(49, 13);
            this.quantityLbl.TabIndex = 3;
            this.quantityLbl.Text = "Quantity:";
            // 
            // productInput
            // 
            this.productInput.Location = new System.Drawing.Point(122, 56);
            this.productInput.Name = "productInput";
            this.productInput.Size = new System.Drawing.Size(121, 20);
            this.productInput.TabIndex = 4;
            // 
            // quantityInput
            // 
            this.quantityInput.Location = new System.Drawing.Point(122, 82);
            this.quantityInput.Name = "quantityInput";
            this.quantityInput.Size = new System.Drawing.Size(121, 20);
            this.quantityInput.TabIndex = 5;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(132, 108);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(100, 25);
            this.calcButton.TabIndex = 6;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // initialCostLbl
            // 
            this.initialCostLbl.AutoSize = true;
            this.initialCostLbl.Location = new System.Drawing.Point(55, 157);
            this.initialCostLbl.Name = "initialCostLbl";
            this.initialCostLbl.Size = new System.Drawing.Size(61, 13);
            this.initialCostLbl.TabIndex = 7;
            this.initialCostLbl.Text = "Initital Cost:";
            // 
            // discCostLbl
            // 
            this.discCostLbl.AutoSize = true;
            this.discCostLbl.Location = new System.Drawing.Point(28, 184);
            this.discCostLbl.Name = "discCostLbl";
            this.discCostLbl.Size = new System.Drawing.Size(88, 13);
            this.discCostLbl.TabIndex = 8;
            this.discCostLbl.Text = "Discounted Cost:";
            // 
            // taxLbl
            // 
            this.taxLbl.AutoSize = true;
            this.taxLbl.Location = new System.Drawing.Point(88, 211);
            this.taxLbl.Name = "taxLbl";
            this.taxLbl.Size = new System.Drawing.Size(28, 13);
            this.taxLbl.TabIndex = 9;
            this.taxLbl.Text = "Tax:";
            // 
            // totPriceLbl
            // 
            this.totPriceLbl.AutoSize = true;
            this.totPriceLbl.Location = new System.Drawing.Point(55, 238);
            this.totPriceLbl.Name = "totPriceLbl";
            this.totPriceLbl.Size = new System.Drawing.Size(61, 13);
            this.totPriceLbl.TabIndex = 10;
            this.totPriceLbl.Text = "Total Price:";
            // 
            // initialCostOut
            // 
            this.initialCostOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.initialCostOut.Location = new System.Drawing.Point(122, 156);
            this.initialCostOut.Name = "initialCostOut";
            this.initialCostOut.Size = new System.Drawing.Size(121, 21);
            this.initialCostOut.TabIndex = 11;
            // 
            // discCostOut
            // 
            this.discCostOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discCostOut.Location = new System.Drawing.Point(122, 183);
            this.discCostOut.Name = "discCostOut";
            this.discCostOut.Size = new System.Drawing.Size(121, 21);
            this.discCostOut.TabIndex = 12;
            // 
            // taxOut
            // 
            this.taxOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxOut.Location = new System.Drawing.Point(122, 210);
            this.taxOut.Name = "taxOut";
            this.taxOut.Size = new System.Drawing.Size(121, 21);
            this.taxOut.TabIndex = 13;
            // 
            // totPriceOut
            // 
            this.totPriceOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totPriceOut.Location = new System.Drawing.Point(122, 237);
            this.totPriceOut.Name = "totPriceOut";
            this.totPriceOut.Size = new System.Drawing.Size(121, 21);
            this.totPriceOut.TabIndex = 14;
            // 
            // Program3
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 286);
            this.Controls.Add(this.totPriceOut);
            this.Controls.Add(this.taxOut);
            this.Controls.Add(this.discCostOut);
            this.Controls.Add(this.initialCostOut);
            this.Controls.Add(this.totPriceLbl);
            this.Controls.Add(this.taxLbl);
            this.Controls.Add(this.discCostLbl);
            this.Controls.Add(this.initialCostLbl);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.quantityInput);
            this.Controls.Add(this.productInput);
            this.Controls.Add(this.quantityLbl);
            this.Controls.Add(this.productLbl);
            this.Controls.Add(this.stateLbl);
            this.Controls.Add(this.selectBox);
            this.Name = "Program3";
            this.Text = "Program 3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox selectBox;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label productLbl;
        private System.Windows.Forms.Label quantityLbl;
        private System.Windows.Forms.TextBox productInput;
        private System.Windows.Forms.TextBox quantityInput;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label initialCostLbl;
        private System.Windows.Forms.Label discCostLbl;
        private System.Windows.Forms.Label taxLbl;
        private System.Windows.Forms.Label totPriceLbl;
        private System.Windows.Forms.Label initialCostOut;
        private System.Windows.Forms.Label discCostOut;
        private System.Windows.Forms.Label taxOut;
        private System.Windows.Forms.Label totPriceOut;
    }
}

